-- Access logic helpers, referenced from locations' access_rules as "$no_gating".
-- Each location rule is ["unlock_<level>", "$no_gating"] (OR). Unlock-item gating
-- only makes sense in OPEN mode once connected: in LINEAR mode levels are
-- token-gated (the unlock is not an item), and before connecting nothing is
-- known. In both of those cases no_gating() returns 1 so checks are NOT greyed.
function no_gating()
  if not SETTINGS then return 1 end
  return (tonumber(SETTINGS.game_mode) == 1) and 1 or 0
end

-- ── Skip-tier helpers (read the player's "skips" setting from slot_data) ──
function skips_off()
  if not SETTINGS then return 1 end
  return (tonumber(SETTINGS.skips) == 0) and 1 or 0
end
function skips_easy_or_hard()
  if not SETTINGS then return 0 end
  local s = tonumber(SETTINGS.skips) or 0
  return (s == 1 or s == 2) and 1 or 0
end
function skips_hard()
  if not SETTINGS then return 0 end
  return (tonumber(SETTINGS.skips) == 2) and 1 or 0
end

-- ── Coin-bundle reachability: "are >= N*bundle_size of this level's coins reachable?" ──
-- COIN_REQ (per level/skip-tier per-coin DNFs) is provided by coin_logic.lua.
local function code_met(code)
  local nm, n = code:match("^(.-):(%d+)$")
  if nm then return Tracker:ProviderCountForCode(nm) >= tonumber(n) end
  return Tracker:ProviderCountForCode(code) >= 1
end
function coinbundle(li, bn)
  li = tonumber(li); bn = tonumber(bn)
  if not COIN_REQ or not COIN_REQ[li] then return 1 end
  local tier = (SETTINGS and tonumber(SETTINGS.skips)) or 0
  local coins = COIN_REQ[li][tier] or COIN_REQ[li][0]
  if not coins then return 1 end
  local total = #coins
  local bsize = (SETTINGS and tonumber(SETTINGS.coinsanity_checks_bundle_size)) or 5
  local K = (bsize == 0) and total or math.min(bn * bsize, total)
  if K <= 0 then return 1 end
  local cnt = 0
  for _, terms in ipairs(coins) do
    local ok = false
    for _, term in ipairs(terms) do
      local all = true
      for _, c in ipairs(term) do if not code_met(c) then all = false break end end
      if all then ok = true break end
    end
    if ok then cnt = cnt + 1; if cnt >= K then return 1 end end
  end
  return (cnt >= K) and 1 or 0
end

-- ── Goal condition check (open mode): tokens / bosses / unlock per slot_data ──
-- Linear mode needs only (Stomp|Spin)+access, so returns 1 there. Boss count uses
-- cleared boss "Defeat Reward 1" checks (the bosses you've actually beaten).
function goalcond()
  if not SETTINGS then return 1 end
  if tonumber(SETTINGS.game_mode) == 1 then return 1 end   -- linear
  local goal = tonumber(SETTINGS.goal_conditions) or 0
  local needs_tokens = (goal==0 or goal==3 or goal==4 or goal==6)
  local needs_bosses = (goal==1 or goal==3 or goal==5 or goal==6)
  local needs_unlock = (goal==2 or goal==4 or goal==5 or goal==6)
  if needs_tokens then
    local gate = tonumber(SETTINGS.final_showdown_token_gate) or 0
    if Tracker:ProviderCountForCode("pizza_planet_token") < gate then return 0 end
  end
  if needs_bosses then
    local req = tonumber(SETTINGS.defeated_bosses_required) or 0
    local cnt = 0
    for _, ab in ipairs({"BA","ST","TBE","EEZ"}) do
      local o = Tracker:FindObjectForCode("@"..ab.."/Defeat Reward 1")
      if o and (o.AvailableChestCount or 1) == 0 then cnt = cnt + 1 end
    end
    if cnt < req then return 0 end
  end
  if needs_unlock then
    if Tracker:ProviderCountForCode("unlock_final_showdown") < 1 then return 0 end
  end
  return 1
end
